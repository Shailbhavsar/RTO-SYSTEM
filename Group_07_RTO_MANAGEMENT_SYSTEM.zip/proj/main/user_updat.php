<?php
session_start();
// include database connection file
include_once "conn.php";

        $database = new connection();
		$db = $database->OpenConnection();

if(isset($_POST['update']))
{
// Get the userid
    $userid=$_SESSION['userid'];
    $name=$_POST['Name'];
    $mno=$_POST['Mobile'];
    $email=$_POST['Email'];
    $gender=$_POST['Gender'];
    $address=$_POST['Address'];
// Query for Updation
$sql="update user set Name=:name,Mno=:mno,Email=:email,Gender=:gender,Address=:address where User_id=:user_id";
//Prepare Query for Execution
$query = $db->prepare($sql);
// Bind the parameters
$data =  [
    ":user_id"=>$userid,
    ":name"=>$name,
    ":mno"=>$mno,
    ":email"=>$email,
    ":gender"=>$gender,
    ":address"=>$address
];       
// Query Execution
$success = $query->execute($data);
// Mesage after updation
if($success) {
    echo "<script>alert('Record Updated successfully');</script>";
    // Code for redirection
    echo "<script>window.location.href='home2.php'</script>";
}

}
?>