<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Validated Login Form</title>
	<link rel="stylesheet" href="st.css">
</head>
<body>
	<div class="container">
		<h1 class="label">User Login</h1>
		<form class="login_form" action="page1.php" method="post" name="form" onsubmit="return validated()">
			<div class="font">Email or Phone</div>
			<input autocomplete="off" type="text" name="email">
			<div id="email_error">Please fill up your Email or Phone</div>
			<div class="font font2">Password</div>
			<input type="password" name="password">
			<div id="pass_error">Please fill up your Password</div>
			<button type="submit">Login</button>
			<div class="signup_link">
				Not a member? <a href="page1.php">Signup</a>
			  </div>
		</form>
	</div>	
	<script src="valid.js"></script>
</body>
</html>