    <?php
include "demo1.php";
    $conn = mysqli_connect("localhost", "root", "", "project");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

    $firstname= $_POST['inputFirstName'];
    $lastname= $_POST['inputLastName'];
    $mail= $_POST['inputEmail'];
    $cont= $_POST['inputNumber'];
    $image= rand(1000,100000)."-".$_FILES['image']['name'];
        $path='upload/'.$image;
        move_uploaded_file($_FILES['image']['tmp_name'],$path);
    $time=$_POST['timings'];
    $date=$_POST['date'];


	$sql = "INSERT INTO DlBOOKING  VALUES ('','$firstname','$lastname','$cont','$image','$time','$date')";
  
	if(mysqli_query($conn, $sql)){
        echo "<script>window.location.href='page1.php'</script>";
        
       
    } else{
		echo "ERROR: Hush! Sorry $sql. "
			. mysqli_error($conn);
	}
    mysqli_close($conn); 

?>
<!--CREATE TABLE DLBOOKING(ID int PRIMARY KEY NOT NULL AUTO_INCREMENT,firstname varchar(50) NOT NULL,lastname varchar(50)  NOT NULL,cont varchar(10) NOT NULL,image varchar(200) NOT NULL, time varchar(100) NOT NULL, date varchar(100) NOT NULL))-->