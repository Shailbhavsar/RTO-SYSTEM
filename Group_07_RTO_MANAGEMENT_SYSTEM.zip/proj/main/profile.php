<?php
session_start();
include_once "demo1.php";

    $database = new connection();
    $db = $database->OpenConnection();
    ?>
     <!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Profile</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body style="background-image:url('bg.jpg');">

    <div class="container">

        <!-- Outer Row -->
        
                    
                        <!-- Nested Row within Card Body -->
                        
                            
                        <center>  <div class="col-lg-6" style="position: relative;
                            top: 150px;" >
                                <div class="p-5" style="background-color:white; border-radius: 25px; box-shadow: 15px 15px 20px;" >
                                    <div class="text-center" >
                                        <h1 class="h4 text-gray-900 mb-4">Profile-<?php echo htmlentities($_SESSION['username']);?></h1>
                                    </div>
                                    <form class="user" method="post" >
                                    <div style="position:absolute;left:70px";>
                                    <p>First Name:</p>
                                    </div> 
                                    <div style="position:absolute;right:30px";>
                                        <?php echo htmlentities($_SESSION['username']);?>
                                        </div>
                                        <br><br><br>
                                        <div style="position:absolute;left:70px";>
                                    <p>Last name:</p>
                                    </div>
                                        <div style="position:absolute;right:30px";>
                                        <?php echo htmlentities($_SESSION['userlname']);?>
                                        </div>
                                        <br><br><br>
                                        <div style="position:absolute;left:70px";>
                                    <p>Email-id:</p>
                                    </div>
                                        <div style="position:absolute;right:30px";>
                                        <?php echo htmlentities($_SESSION['useremail']);?>
                                        </div>
                                        <br><br><br>
                                        <div style="position:absolute;left:70px";>
                                    <p>Age:</p>
                                    </div>
                                        <div style="position:absolute;right:30px";>
                                        <?php echo htmlentities($_SESSION['age']);?>
                                        </div>
                                        <br><br><br>
                                        <div style="position:absolute;left:70px";>
                                    <p>Date Of Birth:</p>
                                    </div>
                                        <div style="position:absolute;right:30px";>
                                        <?php echo htmlentities($_SESSION['dob']);?>
                                        </div>
                                        <br><br><br>
                                        <div style="position:absolute;left:70px";>
                                        <p>Number:</p>
                                    </div>
                                        <div style="position:absolute;right:30px";>
                                        <?php echo htmlentities($_SESSION['number']);?>
                                        </div>
                                        <br><br><br>
                                        <div style="position:absolute;left:70px";>
                                        <p>Password:</p>
                                    </div>
                                        <div style="position:absolute;right:30px";>
                                        <?php echo htmlentities($_SESSION['password']);?>
                                        </div>
                                        <br><br><br>
                                        <div style="position:absolute;left:70px";>
                                        
                                        <a href="in.php" style="position:absolute;left: 500px; bottom: 10px;" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                        Back</a>
                                
                                
                                        <a href="#" style="position:absolute;left: 550px; bottom: 10px;" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                        Edit</a>
                                        </div>
                                        <!-- <a href="index.html" class="btn btn-primary btn-user btn-block">
                                            Login</a>-->
                                        <!-- <center><button type="submit" class="btn" >Save MPIN</button> </center> -->
                                        
                                    </form>
                                    
                                    
                                </div>
                            </div></center>
                        
                   
              
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>