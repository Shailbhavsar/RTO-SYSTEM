    <?php
include "demo1.php";
    $conn = mysqli_connect("localhost", "root", "", "project");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

   
    $message= $_POST['message'];


	$sql = "INSERT INTO feedback(Message) VALUES ('".$message."')";
  
      /*  $data = [
            ":fname"=>$fname,
            ":email"=>$email,
            ":contact"=>$contact,
            ":message"=>$message
        ]I*/

	if(mysqli_query($conn, $sql)){
        echo  "<script>window.location.href='page1.php'</script>";
    } else{
		echo "ERROR: Hush! Sorry $sql. "
			. mysqli_error($conn);
	}
    mysqli_close($conn); 

?>