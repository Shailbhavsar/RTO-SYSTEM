
<?php
session_start();
include_once "demo1.php";
    $database = new connection();
    $db = $database->OpenConnection();

if(isset($_POST['update']))

{
        
        $userid=$_SESSION['userid'];
        $fname=$_POST['first_name'];
        $lname=$_POST['last_name'];
        $dob=$_POST['dob'];
        $age=$_POST['age'];
        $addr=$_POST['addr'];
        $cont=$_POST['num'];
        $mail=$_POST['email'];
        $pass=$_POST['pass'];

       // echo "<script>window.location.href='update_form.php'</script>";
        $sql="update registration set fname=:first_name,lname=:last_name,dob=:dob,age=:age,addr=:addr,cont=:num,mail=:email,pass=:pass where id=:uid";
        
        $query=$db->prepare($sql);

        $data=[
            ':name'=>$_POST['first_name'],
            ':last_name'=>$_POST['last_name'],
            ':dob'=> $_POST['dob'],
            ':age'=> $_POST['age'],
            ':addr'=> $_POST['addr'],
            ':cont'=> $_POST['num'],
            ':mail'=> $_POST['email'],
            ':pass'=> $_POST['pass'],
            ':uid'=>$userid
            
        ];
        $success =$query->execute($data);

        if($success)
        {
            
                $results=$query->fetchAll(PDO::FETCH_ASSOC);
                foreach($results as $result)
                {
                    echo $result['id'] .$result['name'];
                    $_SESSION['userid']=$result['id'];
                    $_SESSION['first_name']=$result['first_name'];
                    $_SESSION['last_name']=$result['last_name'];
                    $_SESSION['dob']=$result['dob'];
                    $_SESSION['age']=$result['age'];
                    $_SESSION['addr']=$result['addr'];
                    $_SESSION['cont']=$result['num'];
                    $_SESSION['email']=$result['email'];
                    $_SESSION['pass']=$result['pass'];
                   
                    echo "<script>window.location.href='page1.php'</script>";
                   // echo "error";
                }
                }
                else{
                    echo "error";
                }
    }
        $database->closeConnection();
    }
    catch(PDOException $s)
    {
        echo "there is some problem in connection".$s->getMessage();
	}

?>   

    
   
{

$query = $db->prepare($sql);
// Bind the parameters
$data =  [
    ":user_id"=>$userid,
    ":name"=>$name,
    ":mno"=>$mno,
    ":email"=>$email,
    ":gender"=>$gender,
    ":address"=>$address
];       
// Query Execution
$success = $query->execute($data);
// Mesage after updation
if($success) {
    echo "<script>alert('Record Updated successfully');</script>";
    // Code for redirection
    echo "<script>window.location.href='home2.php'</script>";
}

}
?> -->
    