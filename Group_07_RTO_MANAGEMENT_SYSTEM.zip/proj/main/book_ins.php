    <?php
include "demo1.php";
    $conn = mysqli_connect("localhost", "root", "", "project");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

    $firstname= $_POST['inputFirstName'];
    $lastname= $_POST['inputLastName'];
    $mail= $_POST['inputEmail'];
    $aadnum= $_POST['inputNumber'];
    $addr=$_POST['inputText'];
    $cont= $_POST['inputNumber'];
    $image= rand(1000,100000)."-".$_FILES['image']['name'];
        $path='upload/'.$image;
        move_uploaded_file($_FILES['image']['tmp_name'],$path);
    $time=$_POST['timings'];
    $date=$_POST['date'];


	$sql = "INSERT INTO BOOKING  VALUES ('','$firstname','$lastname','$mail','$aadnum','$addr','$cont','$image','$time','$date')";
  
	if(mysqli_query($conn, $sql)){
        echo "<script>window.location.href='page1.php'</script>";
        
       
    } else{
		echo "ERROR: Hush! Sorry $sql. "
			. mysqli_error($conn);
	}
    mysqli_close($conn); 

?>