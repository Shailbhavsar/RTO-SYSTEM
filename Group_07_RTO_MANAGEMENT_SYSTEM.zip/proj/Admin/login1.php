<?php
session_start();
include_once "demo1.php";
try
{
    $database = new connection();
    $proj = $database->OpenConnection();
    if(isset($_POST['btn'])){
        $query="SELECT *  FROM registration WHERE email=:email AND password=:password";
        $query_prepare=$db->prepare($query);

        $data=[
            ':email'=> $_POST['email'],
            ':password'=>$_POST['password']
        ];
        $query_run =$query_prepare->execute($data);

        if($query_run)
        {
            $results=$query_prepare->fetchAll(PDO::FETCH_ASSOC);
            foreach($results as $result)
            {
                echo $result['id'] .$result['name'];
                $_SESSION['userid']=$result['id'];
                $_SESSION['username']=$result['name'];
                $_SESSION['useremail']=$result['email'];
                $_SESSION['userpass']=$result['password'];
                header('location:page1.php');
            }
            }
            else{
                echo "error";
            }
    }
        $database->closeConnection();
    }
    catch(PDOException $s)
    {
        echo "there is some problem in connection".$s->getMessage();
	}

?>   

    
   

    