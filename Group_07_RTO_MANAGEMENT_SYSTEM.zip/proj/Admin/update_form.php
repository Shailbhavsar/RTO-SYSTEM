<?php
session_start();
include_once 'demo1.php';

        $database = new connection();
		$db = $database->OpenConnection();

	// Get the userid
	//$userid=intval($_GET['id']);
	$userid=$_SESSION['userid'];
	
	$sql = "SELECT * from registration where id=:id";
	//Prepare the query:
	$query_prepare = $db->prepare($sql);
	//Bind the parameters using array
	$data =  [		
				':id'=>$userid    
	];
	$query_prepare->execute($data);
	$results = $query_prepare->fetchAll(PDO::FETCH_ASSOC);	
	
	$cnt=1;
	if($query_prepare->rowCount() > 0)
	{
	//In case that the query returned at least one record, we can echo the records within a foreach loop:
	foreach($results as $result)
	{
	?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa"></script>
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <style>
        body{
            background: linear-gradient(mediumseagreen, white);
        }
        h1{
            text-align: center;
            color: green;
            font-family:cursive;
        }
        #div1{
            margin-left: 38%;
            width: 25%;
            border-radius: 10px;
            height: 75%;
            margin-top: 75px;
        }
        .nav-item{
            color: #fff
        }
    </style>
    <title>Document</title>
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body>
<nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="#page-top">RTO MANAGEMENT</a>
                <button class="navbar-toggler text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="page1.php">Home</a></li>
                        <!-- <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#about">About</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#contact">Contact</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="login.php">Login</a></li> -->
                    </ul>
                </div>
            </div>
        </nav>
    <h1><strong>Update Form<strong></h1>
    <div id="div1">
    <table>
        <form name="myform"  method="post" action="update.php" onsubmit="return formValidation()">
            <tr>
                <td>First Name:</td>
                <td><input name="first_name" type="text" placeholder="FIRST NAME" ></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <tr>
            <td>Last Name:</td>
            <td><input name="last_name" type="text" placeholder="LAST NAME" ></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <tr>
            <td>date Of Birth:</td>
            <td><input name="dob" type="date" ></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <tr>
            <td>Age:</td>
            <td><input name="age" type="text" placeholder="AGE" ></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <tr>
            <td>Address:</td>
            <td><input name="addr" type="textarea" rows="6" cols="6" placeholder="ADDRESS"></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <tr>
            <td>Contact:</td>
            <td><input name="num" type="tel" placeholder="ENTER YOUR NUMBER"></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <tr>
            <td>Email:</td>
            <td><input name="email" type="email" placeholder="name@gmail.domain"></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <tr>
            <td>Password:</td>
            <td><input name="pass" type="text" placeholder="PASSWORD" ></td>
            </tr>
            <tr>
                <td><br></td>
            </tr>
            <?php }} ?>
            <tr>
            <td><button style="background-color: green;color: antiquewhite;margin-left: 120%; width: 100px;height: 40px;"  type="submit" name="update">UPDATE</a></button></td>
            </tr>
        </form>
    </table>
    </div>


    <script>
function formValidation() {
  //alert("sdfgsdfgsfds");
}
</script>
    <script>
        function formValidation()
        {
            //event.preventDefault();


            //alert("sdfgsdfgsfds");
        var fName=document.myform.first_name.value.trim();
        var lName=document.myform.last_name.value.trim();
        var dob=document.myform.dob.value.trim();
        var age=document.myform.age.value.trim();
        var address=document.myform.addr.value.trim();
        var number=document.myform.num.value.trim();
        var mail=document.myform.email.value.trim();
        var password=document.myform.pass.value.trim();
        var array=[];
        if(fName == null || fName == "")
        {
            alert("Enter your First name");
            return false;
        }
        else if(lName == null || lName == "")
        {
            alert("Enter your Last name");
           
            return false;
        }
        else if(dob == null || dob == "")
        {
            alert("Enter your date of birth");
            
            return false;
        }
        else if(age == null || age == "")
        {
            alert("Enter your Age");
            //window.location.href = 'proj/Registration form.php';
            return false;
        }
        else if(address == null || address == "")
        {
            alert("Enter your address");
            //window.location.href = 'proj/Registration form.php';
            return false;
        }
        else if(number.length !=10)
        {
            alert("Enter correct number");
            //window.location.href = 'proj/Registration form.php';
            return false;
        }  
        else if(mail == null || mail == ""  )
        {
            alert("Enter mail id");
            //window.location.href = 'proj/Registration form.php';
            return false;
        }   
        
        else if(password.length < 8)
        {
            alert("Enter your Password");
           // window.location.href = 'proj/Registration form.php';
            return false;
        }  
    }    
    </script>
</body>
</html>