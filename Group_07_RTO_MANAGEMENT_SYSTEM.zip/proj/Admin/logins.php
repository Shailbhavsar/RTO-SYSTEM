<?php
	include_once 'demo1.php';
	
	try
	{
		
		$database = new connection();
		$db = $database->OpenConnection();
        $email= $_POST['email'];
        $pass= $_POST['password'];

		$match_email = "SELECT * FROM adminlogin WHERE email=:email AND password=:password";
        $stmt = $db->prepare($match_email);
        $stmt->execute([":email" => $email,
                        ":password"=>$pass]);
        $user = $stmt->fetchAll();
		
         $count = sizeof($user);
         //echo "You have already sign up by this email" .$count;
        if($count < 1)
        {
            echo "<script>alert('Email or Password Incorrect')</script>";
            echo "<script>window.location = 'page1.html' </script>";
        }
        else{
            echo "<script>window.location = 'page1.html' </script>";
        }
        $database->closeConnection();
	}
	catch(PDOException $s)
	{
		echo "there is some problem in connection".$s->getMessage();
	}

?>