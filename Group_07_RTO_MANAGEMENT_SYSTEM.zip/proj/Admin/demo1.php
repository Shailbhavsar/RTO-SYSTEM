<?php
	class connection
	{
		private $server = "mysql:host=localhost;dbname=project";
		private $user = "root";
		private $pass = "";
		private $con;
		
		public function OpenConnection()
		{
			try{
				$this->con=new PDO($this->server,$this->user,$this->pass);
				$this->con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
				
				return $this->con;
			}
			catch(PDOException $s)
			{
				echo "This is some problem in connection".$s->getMessage();
			}
			
		}
		
		public function closeConnection()
		{
			$this -> con = null;
		}
	
	}
?>