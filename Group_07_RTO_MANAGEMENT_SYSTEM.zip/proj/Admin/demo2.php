    <?php
include "demo1.php";
    $conn = mysqli_connect("localhost", "root", "", "project");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

    $fname= $_POST['first_name'];
    $lastname= $_POST['last_name'];
    $birth= $_POST['dob'];
    $ag= $_POST['age'];
    $addre= $_POST['addr'];
    $cont= $_POST['num'];
    $mail= $_POST['email'];
    $passwo= $_POST['pass'];




	$sql = "INSERT INTO registration  VALUES ('','$fname','$lastname','$birth','$ag','$addre','$cont','$mail','$passwo')";
  
	if(mysqli_query($conn, $sql)){
        echo "<script>window.location.href='page.php'</script>";
        
       
    } else{
		echo "ERROR: Hush! Sorry $sql. "
			. mysqli_error($conn);
	}
    mysqli_close($conn); 

?>