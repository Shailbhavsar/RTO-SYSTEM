
<?php
session_start();
include_once "demo1.php";
    $database = new connection();
    $db = $database->OpenConnection();

if(isset($_POST['update']))

{
        
        $userid=intval($_SESSION['userid']);
        $fname=$_POST['first_name'];
        $lname=$_POST['last_name'];
        $dob=$_POST['dob'];
        $age=$_POST['age'];
        $addr=$_POST['addr'];
        $cont=$_POST['num'];
        $mail=$_POST['email'];
        $pass=$_POST['pass'];

        //echo "<script>window.location.href='update_form.php'</script>";
        $sql="update registration set FirstName=:first_name,LastName=:last_name,DOB=:dob,AGE=:age,Address=:addr,CONTACT=:num,EMAIl=:email,password=:pass where id=:uid";
        
        $query=$db->prepare($sql);

        $data=[
            ':first_name'=>$_POST['first_name'],           
            ':last_name'=>$_POST['last_name'],
            ':dob'=>$_POST['dob'],
            ':age'=>$_POST['age'],
            ':Addr'=>$_POST['addr'],
            ':num'=>$_POST['num'],
            ':email'=>$_POST['email'],
            ':pass'=>$_POST['pass'],
            ':uid'=>$userid
            
        ];
        $success =$query->execute($data);

        if($success) {

            $results=$query->fetchAll(PDO::FETCH_ASSOC);
            foreach($results as $result)
            {
                echo $result['id'] .$result['name'];
                $_SESSION['userid']=$result['id'];
                $_SESSION['username']=$result['first_name'];
                $_SESSION['userlname']=$result['last_name'];
                $_SESSION['useremail']=$result['email'];
                //echo "<script>alert('Record Updated successfully');</script>";
            // Code for redirection
            echo "<script>window.location.href='page2.php'</script>";
        }
    }
}
?>  




