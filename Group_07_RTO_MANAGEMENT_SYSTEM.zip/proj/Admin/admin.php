<?php
	include_once 'demo1.php';
	
	try
	{
		
	$database=new connection();
    $db=$database->OpenConnection();

	$email=$_POST['email'];
	$password_ins=$_POST['password'];


    $sql="INSERT INTO adminlogin(id,email,password)
	VALUES (:id,:email,:password)";
	$sql_prepare=$db->prepare($sql);
	$data=[":id"=>0,
			
			":email"=>"tejmandaliya1666@gmail.com",
			":password"=>"2583",
			
	];
	$sql_execute = $sql_prepare->execute($data);
	if($sql_execute){
		echo "<script>window.location ='main.html' </script>" ;
	}else{
		echo "failed";
	}
	$database->closeConnection();
}catch(PDOExcecution $s)
{
	echo "ERROR".$s->getMessage();
}
?>