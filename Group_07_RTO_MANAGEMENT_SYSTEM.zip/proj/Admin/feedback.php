<!DOCTYPE html>
<html lang="en">
    <head>
         
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <style>
            .drop{
                
                text-decoration:none;
                text-align: center;

            }
            ul li a{
                text-decoration: nonw;
                color: white;
                display: block;
                line-height: 20px;
                

            }
            ul li a:hover{
               background-color: lightblack; 
            
            }
            ul li ul li{
                display: none;

            }
            ul li:hover ul li{
                display: block;
            }

            .user{
                color: white;
                margin-left: 20px;
                margin-top: -7px; 
            }
            </style>
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="#page-top">RTO MANAGEMENT</a>
                <button class="navbar-toggler text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                 
                <ul class="navbar-nav ms-auto">
                        <li class="drop"><a href="page1.php" style="margin-top: 16px; text-decoration:none; ">Home</a>
                         <!-- <ul>
                           <li class="drop"><a href="Booking.html" style=" text-decoration:none; text-align:center; line-height:20px;">LLR BOOKING</a></li>
                           <li class="drop"><a href="dlbooking.html" style=" text-decoration:none;text-align:center; line-height:20px;">DL BOOKING</a></li>
                           <li class="drop"><a href="#"style=" text-decoration:none; line-height:20px;" >--</a></li>
                        </ul>
                        </li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#about">About</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#contact">Contact</a></li> -->
                        <!-- <li class="drop"><a href="#" style="margin-top: 16px; text-decoration:none; ">Profile</a>
                        <ul>
                        <li class="drop"><a href="profile.php" style=" text-decoration:none; text-align:center; line-height:20px;">View Profile</a></li>
                           <li class="drop"><a href="#" style=" text-decoration:none;text-align:center; line-height:20px;">Edit Profile</a></li>
                        </ul> -->
                           
                        </li >
                        <!-- <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="#">Feedback</a></li> -->
                         <!-- <option>View Profile</option> -->
                         <!-- <option>Edit Profile</option> -->
                         <!-- <li class="nav-item mx-0 mx-lg-1">
                             <img src="user.jpeg" style="height: 30px; width: 30px; margin-left: 10px; margin-top: 5px; position: absolute; border-radius: 20px;"  >
                            <li class="nav-item mx-0 mx-lg-1">
                            <span  class="nav-link py-3 px-0 px-lg-3 rounded  user"   style=""><?php echo htmlentities($_SESSION['username']);?></span>
                            <ul>
                        <li class="drop"><a href="profile.php" style=" text-decoration:none; text-align:center; line-height:20px;">View Profile</a></li>
                           <li class="drop"><a href="update_form.php" style=" text-decoration:none;text-align:center; line-height:20px;">Edit Profile</a></li>
                        </ul>
                        </li> -->
                        
                    </li>
                </ul>
                  
                
            </div>
        </nav>

<section class="page-section" id="contact">
<div class="container">
    <!-- Contact Section Heading-->
    <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">FEED-BACK</h2>
    <!-- Icon Divider-->
    <div class="divider-custom">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
        <div class="divider-custom-line"></div>
    </div>
    <!-- Contact Section Form-->
    <div class="row justify-content-center">
        <div class="col-lg-8 col-xl-7">
            <!-- * * * * * * * * * * * * * * *-->
            <!-- * * SB Forms Contact Form * *-->
            <!-- * * * * * * * * * * * * * * *-->
            <!-- This form is pre-integrated with SB Forms.-->
            <!-- To make this form functional, sign up at-->
            <!-- https://startbootstrap.com/solution/contact-forms-->
            <!-- to get an API token!-->
            <form id="contactForm"  action="feed_insert.php" method="post">
                <!-- Name input-->
                
                <!-- Message input-->
                <div class="form-floating mb-3">
                    <textarea class="form-control" id="message" name="message" type="text" placeholder="Enter your message here..." style="height: 10rem" data-sb-validations="required"></textarea>
                    <label name="message">Message</label>
                    <div class="invalid-feedback" data-sb-feedback="message:required">A message is required.</div>
                </div>
                <!-- Submit success message-->
                <!---->
                <!-- This is what your users will see when the form-->
                <!-- has successfully submitted-->
                <div class="d-none" id="submitSuccessMessage">
                    <div class="text-center mb-3">
                        <div class="fw-bolder">Form submission successful!</div>
                        To activate this form, sign up at
                        <br />
                        <a href="https://startbootstrap.com/solution/contact-forms">https://startbootstrap.com/solution/contact-forms</a>
                    </div>
                </div>
                <!-- Submit error message-->
                <!---->
                <!-- This is what your users will see when there is-->
                <!-- an error submitting the form-->
                <div class="d-none" id="submitErrorMessage"><div class="text-center text-danger mb-3">Error sending message!</div></div>
                <!-- Submit Button-->
                <button class="btn btn-primary btn-xl" id="submitButton" type="submit" >Send</button>
            </form>
        </div>
    </div>
</div>
</section>
</body>
</html>

